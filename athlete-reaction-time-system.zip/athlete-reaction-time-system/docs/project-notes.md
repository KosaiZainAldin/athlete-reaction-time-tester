# Project Notes

## Confirmed project information

- Course: ENGR 107, section 001
- Project: Prototype for Testing Reaction Time for Athletes
- The prototype uses physical push buttons.
- The device was connected to a laptop running MATLAB.
- MATLAB received input values and plotted reaction time data in real time.
- My contribution: Arduino hardware assembly.
- Other team roles included 3D modeling and printing, programming, and documentation.

## Confirm before publishing

- Confirm permission to publish the project materials and demonstration video.
- Confirm all team members' names and how each person wants their contribution described.
- Confirm whether the original Arduino and MATLAB source code can be recovered.
- If code is recreated, identify it as a new implementation rather than the original class submission.
- Confirm which design goals were actually tested and achieved.

## Design goals from the team presentation

The presentation listed portability, analysis of improvement in reaction time, computer connectivity for data analysis, and standalone operation with a target battery life of at least one hour.

The presentation also described use of the Waterfall project management process. These notes preserve the goals as stated in the presentation and do not assume that every target was achieved.
